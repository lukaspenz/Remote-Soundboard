REMOTE SOUNDBOARD - PORTABLE EDITION
=====================================

QUICK START:
1. Double-click "soundboard.exe" to start the server
2. Open your browser to: http://localhost:3030
3. Click "Network" to see the URL for remote devices

ADDING SOUNDS:
- Click "Manage Sounds" button in the app
- Upload files or add existing ones from the sounds folder
- Or manually place audio files in the "sounds" folder

PASSWORD:
- Default password for remote devices: soundboard123
- Host PC (localhost) does not need password
- To change: Edit start.bat and set your password

REQUIREMENTS:
- Windows 10 or later
- No Node.js installation needed!
- Web browser (Chrome/Edge recommended)

TROUBLESHOOTING:
- If port 3030 is busy, close the app and try again
- For remote access, ensure devices are on same network
- Check Windows Firewall if remote devices can't connect
- For password issues, see start.bat to set custom password

FEATURES:
- Remote triggering from phone/tablet
- Audio device selection (choose which speakers)
- Sound management (add, rename, delete sounds)
- File upload from browser
- Real-time sync across all devices
- Password protection for remote access

Enjoy your portable soundboard!

Version 1.0.0 - https://github.com/your-username/remote-soundboard
